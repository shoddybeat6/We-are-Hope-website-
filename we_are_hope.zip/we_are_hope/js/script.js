const volunteerForm = document.getElementById("volunteerForm");

if (volunteerForm) {

    volunteerForm.addEventListener("submit", function(event) {

        event.preventDefault();

        alert("Thank you for applying to volunteer with We Are Hope!");

        volunteerForm.reset();

    });

}


const donationForm = document.getElementById("donationForm");

if (donationForm) {

    donationForm.addEventListener("submit", function(event) {

        event.preventDefault();

        alert("Thank you for supporting We Are Hope!");

        donationForm.reset();

    });

}


const contactForm = document.getElementById("contactForm");

if (contactForm) {

    contactForm.addEventListener("submit", function(event) {

        event.preventDefault();

        alert("Thank you for contacting We Are Hope!");

        contactForm.reset();

    });

}